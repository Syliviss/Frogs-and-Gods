/**
 * game.schema.ts
 *
 * Zod-powered schema for the World Log pipeline.  Every payload that
 * enters the system — whether from the database, the router, or the
 * WebSocket wire — is validated against `WorldLogPayloadSchema` so
 * that downstream code can trust the shape at compile time *and*
 * runtime.
 *
 * Changes from the original untyped interface:
 *   1. Backed by a Zod schema for runtime validation + static inference.
 *   2. Added optional fields: damage, healing, xpGained, lootDropped.
 *   3. Exported both the schema (for parsing) and the inferred TS type.
 */

import { z } from "zod";

/* ------------------------------------------------------------------ */
/*  Loot item sub-schema                                               */
/* ------------------------------------------------------------------ */

export const LootItemSchema = z.object({
  itemId: z.string(),
  name: z.string(),
  rarity: z.enum(["common", "uncommon", "rare", "epic", "legendary"]),
  quantity: z.number().int().positive(),
});

export type LootItem = z.infer<typeof LootItemSchema>;

/* ------------------------------------------------------------------ */
/*  World Log event types                                              */
/* ------------------------------------------------------------------ */

export const WorldLogEventType = z.enum([
  "combat",
  "exploration",
  "dialogue",
  "godIntervention",
]);

export type WorldLogEventType = z.infer<typeof WorldLogEventType>;

/* ------------------------------------------------------------------ */
/*  WorldLogPayload — the main schema                                  */
/* ------------------------------------------------------------------ */

export const WorldLogPayloadSchema = z.object({
  /** Unique identifier for this log entry. */
  eventId: z.string().uuid(),

  /** Unix-epoch millisecond timestamp. */
  timestamp: z.number().int().nonnegative(),

  /** Discriminator for the kind of world event. */
  type: WorldLogEventType,

  /** The Frog (or entity) that triggered or received the event. */
  actorId: z.string(),

  /** Human-readable description of what happened. */
  message: z.string(),

  /* ---------- optional combat / reward fields -------------------- */

  /** Damage dealt during this event (if applicable). */
  damage: z.number().nonnegative().optional(),

  /** Healing received during this event (if applicable). */
  healing: z.number().nonnegative().optional(),

  /** XP gained as a result of this event (if applicable). */
  xpGained: z.number().nonnegative().optional(),

  /** Items dropped as loot during this event (if applicable). */
  lootDropped: z.array(LootItemSchema).optional(),
});

/**
 * Static TypeScript type inferred from the Zod schema.
 *
 * Use this wherever you need compile-time typing without pulling in
 * the schema object itself (e.g. in React component props).
 */
export type WorldLogPayload = z.infer<typeof WorldLogPayloadSchema>;

/* ------------------------------------------------------------------ */
/*  JSON-string variant (for the router transform)                     */
/* ------------------------------------------------------------------ */

/**
 * Accepts a raw JSON **string**, parses it, and validates the result
 * against `WorldLogPayloadSchema`.  This replaces the manual
 * `JSON.parse` + type-assertion pattern that was previously used in
 * the router.
 */
export const WorldLogPayloadFromJsonSchema = z
  .string()
  .transform((raw, ctx) => {
    try {
      return JSON.parse(raw) as unknown;
    } catch {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Invalid JSON string",
      });
      return z.NEVER;
    }
  })
  .pipe(WorldLogPayloadSchema);
