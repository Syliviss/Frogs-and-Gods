/**
 * ============================================================
 * BUGGY VERSION — kept for reference only.
 * ============================================================
 *
 * Problems:
 *   1. WorldLogPayload is a plain TypeScript interface with no
 *      runtime validation — anything can slip through.
 *   2. Missing optional fields for damage, healing, xpGained,
 *      and lootDropped, so combat/reward events are untyped.
 *   3. No Zod schema, so the router must rely on manual
 *      JSON.parse with no structural guarantees.
 */

export interface WorldLogPayloadBuggy {
  eventId: string;
  timestamp: number;
  type: "combat" | "exploration" | "dialogue" | "godIntervention";
  actorId: string;
  message: string;
}
