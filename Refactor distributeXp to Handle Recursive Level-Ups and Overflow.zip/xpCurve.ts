/**
 * Returns the total XP required to advance from `level` to `level + 1`.
 *
 * Formula: 100 * level^1.5  (rounded down)
 *
 * Examples:
 *   Level 1 → 2 :   100 XP
 *   Level 2 → 3 :   282 XP
 *   Level 3 → 4 :   519 XP
 *   Level 4 → 5 :   800 XP
 *   Level 5 → 6 :  1118 XP
 *   Level 6 → 7 :  1469 XP
 *   Level 7 → 8 :  1852 XP
 *   Level 8 → 9 :  2262 XP
 *   Level 9 → 10:  2700 XP
 */
export function xpToNextLevel(level: number): number {
  if (level < 1) {
    throw new RangeError("Level must be >= 1");
  }
  return Math.floor(100 * Math.pow(level, 1.5));
}
