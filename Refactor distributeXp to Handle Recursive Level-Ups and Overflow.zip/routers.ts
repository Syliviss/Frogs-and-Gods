/**
 * routers.ts
 *
 * Simulated tRPC-style router for the World Log pipeline.
 *
 * Refactored to replace the manual `JSON.parse` + type-assertion
 * pattern with a **Zod-validated transform**.  Every row that comes
 * back from the database is now parsed *and* structurally validated
 * in a single step via `WorldLogPayloadFromJsonSchema`.
 *
 * If a row contains invalid JSON or a payload that does not match the
 * schema, the transform returns a structured `ZodError` instead of
 * silently producing `undefined` property accesses at runtime.
 */

import { z } from "zod";
import {
  WorldLogPayload,
  WorldLogPayloadSchema,
  WorldLogPayloadFromJsonSchema,
} from "./game.schema";

/* ------------------------------------------------------------------ */
/*  Simulated DB row (payload stored as a JSON string column)          */
/* ------------------------------------------------------------------ */

export interface DbWorldLogRow {
  id: number;
  payload: string; // raw JSON stored in a TEXT / JSONB column
  createdAt: Date;
}

/* ------------------------------------------------------------------ */
/*  Parsed result wrapper                                              */
/* ------------------------------------------------------------------ */

/**
 * Each row is returned together with its parse outcome so the caller
 * can decide how to handle failures (log, skip, surface to the UI,
 * etc.) without the router swallowing errors silently.
 */
export type ParsedWorldLogRow =
  | { success: true; rowId: number; data: WorldLogPayload }
  | { success: false; rowId: number; error: z.ZodError };

/* ------------------------------------------------------------------ */
/*  Router                                                             */
/* ------------------------------------------------------------------ */

export const worldLogRouter = {
  /**
   * `worldLog.recent` — fetch the most recent world-log entries.
   *
   * Every row's `payload` column (a raw JSON string) is run through
   * `WorldLogPayloadFromJsonSchema`, which:
   *
   *   1. Parses the JSON string (`z.string().transform(JSON.parse)`).
   *   2. Pipes the result into `WorldLogPayloadSchema` for full
   *      structural validation.
   *
   * Rows that fail validation are **not** silently dropped; they are
   * returned with `success: false` and the corresponding `ZodError`.
   */
  recent(rows: DbWorldLogRow[]): ParsedWorldLogRow[] {
    return rows.map((row) => {
      const result = WorldLogPayloadFromJsonSchema.safeParse(row.payload);

      if (result.success) {
        return { success: true as const, rowId: row.id, data: result.data };
      }

      return { success: false as const, rowId: row.id, error: result.error };
    });
  },

  /**
   * `worldLog.single` — parse and validate a single already-parsed
   * object (e.g. from a WebSocket push or an in-memory cache).
   *
   * Uses `WorldLogPayloadSchema` directly (no JSON-string step).
   */
  single(obj: unknown): WorldLogPayload {
    return WorldLogPayloadSchema.parse(obj);
  },
};
