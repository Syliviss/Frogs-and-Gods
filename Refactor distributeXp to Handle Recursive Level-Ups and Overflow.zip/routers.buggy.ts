/**
 * ============================================================
 * BUGGY VERSION — kept for reference only.
 * ============================================================
 *
 * Problems:
 *   1. Uses manual JSON.parse with a bare type assertion
 *      (`as WorldLogPayloadBuggy`).  If the stored JSON is
 *      malformed or missing fields the code silently produces
 *      `undefined` property accesses at runtime.
 *   2. No runtime validation — the TypeScript type provides
 *      zero protection once the code is compiled to JavaScript.
 */

import { WorldLogPayloadBuggy } from "./game.schema.buggy";

/* ------------------------------------------------------------------ */
/*  Simulated DB row (payload stored as a JSON string column)          */
/* ------------------------------------------------------------------ */

interface DbWorldLogRow {
  id: number;
  payload: string; // raw JSON
  createdAt: Date;
}

/* ------------------------------------------------------------------ */
/*  Simulated tRPC-style router                                        */
/* ------------------------------------------------------------------ */

export const worldLogRouterBuggy = {
  recent: (rows: DbWorldLogRow[]): WorldLogPayloadBuggy[] => {
    return rows.map((row) => {
      // BUG: no validation — trusting the DB blindly
      const parsed = JSON.parse(row.payload) as WorldLogPayloadBuggy;
      return parsed;
    });
  },
};
