/**
 * xpDistributor.ts
 *
 * Distributes XP to a Frog and processes all resulting level-ups,
 * including cases where the awarded XP is large enough to skip
 * multiple levels in a single call.
 *
 * Refactored to fix two bugs in the original implementation:
 *   1. Only a single level-up was processed per call.
 *   2. Leftover XP was discarded (reset to 0) instead of being
 *      carried over as progress toward the next level.
 */

import { Frog } from "./frog";
import { xpToNextLevel } from "./xpCurve";

/* ------------------------------------------------------------------ */
/*  Result interface                                                   */
/* ------------------------------------------------------------------ */

/**
 * Returned by `distributeXp` to summarise what happened.
 *
 * - `leveledUp`   – `true` if **any** level was gained (one or more).
 * - `newLevel`    – the Frog's level after all level-ups are applied.
 * - `remainingXp` – leftover XP that counts toward the *next* level
 *                   (this is the value persisted back to the database).
 */
export interface XpResult {
  leveledUp: boolean;
  newLevel: number;
  remainingXp: number;
}

/* ------------------------------------------------------------------ */
/*  Core function                                                      */
/* ------------------------------------------------------------------ */

/**
 * Award `xpGained` experience points to `frog` and process every
 * resulting level-up.
 *
 * The function uses a **while-loop** that keeps levelling the Frog up
 * as long as its accumulated XP meets or exceeds the threshold for the
 * current level.  After the loop the Frog's `xp` field holds only the
 * remainder — i.e. progress toward the *next* level — which is the
 * value that should be written back to the database.
 *
 * @param frog     The Frog entity (mutated in place).
 * @param xpGained Non-negative amount of XP to award.
 * @returns        An {@link XpResult} summarising the outcome.
 */
export function distributeXp(frog: Frog, xpGained: number): XpResult {
  if (xpGained < 0) {
    throw new RangeError("xpGained must be >= 0");
  }

  const startLevel = frog.level;

  // Add the earned XP to the Frog's current pool.
  frog.xp += xpGained;

  // Keep levelling up while accumulated XP meets or exceeds the
  // threshold for the current level.
  let threshold = xpToNextLevel(frog.level);
  while (frog.xp >= threshold) {
    frog.xp -= threshold;   // carry over the remainder
    frog.level += 1;
    threshold = xpToNextLevel(frog.level);
  }

  return {
    leveledUp: frog.level > startLevel,
    newLevel: frog.level,
    remainingXp: frog.xp,
  };
}
