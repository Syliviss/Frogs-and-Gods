/**
 * Represents a Frog entity as stored in the database.
 */
export interface Frog {
  id: string;
  name: string;
  level: number;
  xp: number; // current XP accumulated toward the next level
}
