/**
 * ============================================================
 * BUGGY VERSION — kept for reference only.
 * ============================================================
 *
 * Problems:
 *   1. Only checks for a single level-up; if the awarded XP is
 *      large enough to skip two or more levels, only one is
 *      processed.
 *   2. Resets `xp` to 0 on level-up instead of carrying over
 *      the remainder.
 *   3. `XpResult` does not expose `remainingXp`.
 */

import { Frog } from "./frog";
import { xpToNextLevel } from "./xpCurve";

export interface XpResultBuggy {
  leveledUp: boolean;
  newLevel: number;
}

export function distributeXpBuggy(frog: Frog, xpGained: number): XpResultBuggy {
  frog.xp += xpGained;

  if (frog.xp >= xpToNextLevel(frog.level)) {
    frog.level += 1;
    frog.xp = 0; // BUG: remainder is lost
    return { leveledUp: true, newLevel: frog.level };
  }

  return { leveledUp: false, newLevel: frog.level };
}
