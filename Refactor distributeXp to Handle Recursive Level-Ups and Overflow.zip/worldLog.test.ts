/**
 * worldLog.test.ts — Unit tests for the strictly-typed World Log pipeline.
 *
 * Covers:
 *   1. game.schema.ts   — Zod schema validation (valid + invalid payloads)
 *   2. routers.ts        — Zod-validated transform replacing manual JSON.parse
 *   3. useWorldLog.ts    — Type guard + hook resilience to malformed messages
 *
 * Run with:
 *   npx ts-node tests/worldLog.test.ts
 */

import {
  WorldLogPayloadSchema,
  WorldLogPayloadFromJsonSchema,
  WorldLogPayload,
  LootItemSchema,
} from "../src/game.schema";
import { worldLogRouter, DbWorldLogRow } from "../src/routers";
import { isWorldLogPayload, useWorldLog } from "../src/useWorldLog";

/* ------------------------------------------------------------------ */
/*  Tiny assertion helpers                                             */
/* ------------------------------------------------------------------ */

let passed = 0;
let failed = 0;

function assert(condition: boolean, label: string): void {
  if (condition) {
    passed++;
    console.log(`  ✓  ${label}`);
  } else {
    failed++;
    console.error(`  ✗  ${label}`);
  }
}

function assertEqual<T>(actual: T, expected: T, label: string): void {
  assert(
    actual === expected,
    `${label} — expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
  );
}

function assertDeepEqual<T>(actual: T, expected: T, label: string): void {
  assert(
    JSON.stringify(actual) === JSON.stringify(expected),
    `${label} — expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
  );
}

function section(title: string): void {
  console.log(`\n── ${title} ${"─".repeat(Math.max(2, 58 - title.length))}`);
}

/* ------------------------------------------------------------------ */
/*  Fixtures                                                           */
/* ------------------------------------------------------------------ */

const VALID_COMBAT_PAYLOAD: WorldLogPayload = {
  eventId: "550e8400-e29b-41d4-a716-446655440000",
  timestamp: 1714000000000,
  type: "combat",
  actorId: "frog-001",
  message: "Kermit slashes the Swamp Troll for 42 damage!",
  damage: 42,
  healing: undefined,
  xpGained: 150,
  lootDropped: [
    { itemId: "loot-001", name: "Troll Fang", rarity: "uncommon", quantity: 1 },
  ],
};

const VALID_EXPLORATION_PAYLOAD: WorldLogPayload = {
  eventId: "660e8400-e29b-41d4-a716-446655440001",
  timestamp: 1714000060000,
  type: "exploration",
  actorId: "frog-002",
  message: "Ribbit discovers a hidden cave.",
};

const VALID_GOD_INTERVENTION: WorldLogPayload = {
  eventId: "770e8400-e29b-41d4-a716-446655440002",
  timestamp: 1714000120000,
  type: "godIntervention",
  actorId: "frog-001",
  message: "A divine hand heals Kermit for 999 HP.",
  healing: 999,
};

/* ================================================================== */
/*  1. game.schema.ts — WorldLogPayloadSchema                          */
/* ================================================================== */

section("Schema: valid combat payload (all optional fields present)");

{
  const result = WorldLogPayloadSchema.safeParse(VALID_COMBAT_PAYLOAD);
  assertEqual(result.success, true, "parses successfully");
  if (result.success) {
    assertEqual(result.data.damage, 42, "damage is 42");
    assertEqual(result.data.xpGained, 150, "xpGained is 150");
    assertEqual(result.data.lootDropped?.length, 1, "lootDropped has 1 item");
    assertEqual(result.data.lootDropped?.[0]?.rarity, "uncommon", "rarity is uncommon");
  }
}

section("Schema: valid exploration payload (no optional fields)");

{
  const result = WorldLogPayloadSchema.safeParse(VALID_EXPLORATION_PAYLOAD);
  assertEqual(result.success, true, "parses successfully");
  if (result.success) {
    assertEqual(result.data.damage, undefined, "damage is undefined");
    assertEqual(result.data.healing, undefined, "healing is undefined");
    assertEqual(result.data.xpGained, undefined, "xpGained is undefined");
    assertEqual(result.data.lootDropped, undefined, "lootDropped is undefined");
  }
}

section("Schema: valid godIntervention payload");

{
  const result = WorldLogPayloadSchema.safeParse(VALID_GOD_INTERVENTION);
  assertEqual(result.success, true, "parses successfully");
  if (result.success) {
    assertEqual(result.data.type, "godIntervention", "type is godIntervention");
    assertEqual(result.data.healing, 999, "healing is 999");
  }
}

section("Schema: rejects missing required fields");

{
  const incomplete = { eventId: "not-a-uuid", timestamp: 100 };
  const result = WorldLogPayloadSchema.safeParse(incomplete);
  assertEqual(result.success, false, "rejects incomplete payload");
}

section("Schema: rejects invalid eventId (not a UUID)");

{
  const bad = { ...VALID_EXPLORATION_PAYLOAD, eventId: "not-a-uuid" };
  const result = WorldLogPayloadSchema.safeParse(bad);
  assertEqual(result.success, false, "rejects non-UUID eventId");
}

section("Schema: rejects negative damage");

{
  const bad = { ...VALID_COMBAT_PAYLOAD, damage: -10 };
  const result = WorldLogPayloadSchema.safeParse(bad);
  assertEqual(result.success, false, "rejects negative damage");
}

section("Schema: rejects unknown event type");

{
  const bad = { ...VALID_EXPLORATION_PAYLOAD, type: "earthquake" };
  const result = WorldLogPayloadSchema.safeParse(bad);
  assertEqual(result.success, false, "rejects unknown type 'earthquake'");
}

section("Schema: rejects invalid loot rarity");

{
  const bad = {
    ...VALID_COMBAT_PAYLOAD,
    lootDropped: [
      { itemId: "x", name: "Bad", rarity: "mythic", quantity: 1 },
    ],
  };
  const result = WorldLogPayloadSchema.safeParse(bad);
  assertEqual(result.success, false, "rejects unknown rarity 'mythic'");
}

/* ================================================================== */
/*  2. game.schema.ts — WorldLogPayloadFromJsonSchema (JSON transform) */
/* ================================================================== */

section("JSON transform: valid JSON string → WorldLogPayload");

{
  const json = JSON.stringify(VALID_COMBAT_PAYLOAD);
  const result = WorldLogPayloadFromJsonSchema.safeParse(json);
  assertEqual(result.success, true, "parses valid JSON string");
  if (result.success) {
    assertEqual(result.data.eventId, VALID_COMBAT_PAYLOAD.eventId, "eventId matches");
    assertEqual(result.data.damage, 42, "damage carried through");
  }
}

section("JSON transform: rejects malformed JSON string");

{
  const result = WorldLogPayloadFromJsonSchema.safeParse("{broken json");
  assertEqual(result.success, false, "rejects broken JSON");
}

section("JSON transform: rejects valid JSON with wrong shape");

{
  const json = JSON.stringify({ foo: "bar" });
  const result = WorldLogPayloadFromJsonSchema.safeParse(json);
  assertEqual(result.success, false, "rejects wrong-shape JSON");
}

/* ================================================================== */
/*  3. routers.ts — worldLogRouter.recent                              */
/* ================================================================== */

section("Router: recent() parses valid rows");

{
  const rows: DbWorldLogRow[] = [
    {
      id: 1,
      payload: JSON.stringify(VALID_COMBAT_PAYLOAD),
      createdAt: new Date(),
    },
    {
      id: 2,
      payload: JSON.stringify(VALID_EXPLORATION_PAYLOAD),
      createdAt: new Date(),
    },
  ];

  const results = worldLogRouter.recent(rows);
  assertEqual(results.length, 2, "returns 2 results");
  assertEqual(results[0]!.success, true, "row 1 succeeds");
  assertEqual(results[1]!.success, true, "row 2 succeeds");

  if (results[0]!.success) {
    assertEqual(results[0]!.data.type, "combat", "row 1 type is combat");
  }
}

section("Router: recent() surfaces errors for bad rows without crashing");

{
  const rows: DbWorldLogRow[] = [
    { id: 10, payload: "not json at all", createdAt: new Date() },
    {
      id: 11,
      payload: JSON.stringify({ eventId: "bad" }),
      createdAt: new Date(),
    },
    {
      id: 12,
      payload: JSON.stringify(VALID_GOD_INTERVENTION),
      createdAt: new Date(),
    },
  ];

  const results = worldLogRouter.recent(rows);
  assertEqual(results.length, 3, "returns 3 results");
  assertEqual(results[0]!.success, false, "row 10 fails (bad JSON)");
  assertEqual(results[0]!.rowId, 10, "row 10 id preserved");
  assertEqual(results[1]!.success, false, "row 11 fails (wrong shape)");
  assertEqual(results[2]!.success, true, "row 12 succeeds");
}

section("Router: single() parses a valid object");

{
  const data = worldLogRouter.single(VALID_GOD_INTERVENTION);
  assertEqual(data.type, "godIntervention", "type is godIntervention");
  assertEqual(data.healing, 999, "healing is 999");
}

section("Router: single() throws on invalid object");

{
  let threw = false;
  try {
    worldLogRouter.single({ garbage: true });
  } catch {
    threw = true;
  }
  assert(threw, "single() throws ZodError for invalid input");
}

/* ================================================================== */
/*  4. useWorldLog.ts — isWorldLogPayload type guard                   */
/* ================================================================== */

section("Type guard: accepts valid payload");

{
  assertEqual(isWorldLogPayload(VALID_COMBAT_PAYLOAD), true, "combat payload accepted");
  assertEqual(isWorldLogPayload(VALID_EXPLORATION_PAYLOAD), true, "exploration accepted");
  assertEqual(isWorldLogPayload(VALID_GOD_INTERVENTION), true, "godIntervention accepted");
}

section("Type guard: rejects garbage");

{
  assertEqual(isWorldLogPayload(null), false, "null rejected");
  assertEqual(isWorldLogPayload(undefined), false, "undefined rejected");
  assertEqual(isWorldLogPayload(42), false, "number rejected");
  assertEqual(isWorldLogPayload("hello"), false, "string rejected");
  assertEqual(isWorldLogPayload({ foo: "bar" }), false, "wrong object rejected");
}

section("Type guard: rejects malformed God intervention");

{
  const malformed = {
    eventId: "not-a-uuid",
    timestamp: "not-a-number",
    type: "godIntervention",
    actorId: 123,
    // message missing entirely
  };
  assertEqual(isWorldLogPayload(malformed), false, "malformed god intervention rejected");
}

/* ================================================================== */
/*  5. useWorldLog.ts — hook handleMessage                             */
/* ================================================================== */

section("Hook: valid message reaches onEntry");

{
  const received: WorldLogPayload[] = [];
  const { handleMessage } = useWorldLog({
    onEntry: (e) => received.push(e),
  });

  handleMessage({ data: JSON.stringify(VALID_COMBAT_PAYLOAD) });
  assertEqual(received.length, 1, "onEntry called once");
  assertEqual(received[0]!.eventId, VALID_COMBAT_PAYLOAD.eventId, "correct eventId");
}

section("Hook: malformed message triggers onError, not onEntry");

{
  const entries: WorldLogPayload[] = [];
  const errors: Array<{ raw: unknown; reason: string }> = [];

  const { handleMessage } = useWorldLog({
    onEntry: (e) => entries.push(e),
    onError: (raw, reason) => errors.push({ raw, reason }),
  });

  // Broken JSON
  handleMessage({ data: "{not json" });
  assertEqual(entries.length, 0, "onEntry not called for broken JSON");
  assertEqual(errors.length, 1, "onError called for broken JSON");

  // Valid JSON, wrong shape
  handleMessage({ data: JSON.stringify({ x: 1 }) });
  assertEqual(entries.length, 0, "onEntry still not called");
  assertEqual(errors.length, 2, "onError called again for wrong shape");
}

section("Hook: malformed God intervention does not crash");

{
  const entries: WorldLogPayload[] = [];
  const errors: Array<{ raw: unknown; reason: string }> = [];

  const { handleMessage } = useWorldLog({
    onEntry: (e) => entries.push(e),
    onError: (raw, reason) => errors.push({ raw, reason }),
  });

  const malformedGod = {
    eventId: "not-uuid",
    type: "godIntervention",
    // missing timestamp, actorId, message
  };
  handleMessage({ data: JSON.stringify(malformedGod) });

  assertEqual(entries.length, 0, "onEntry not called");
  assertEqual(errors.length, 1, "onError called");
  assert(
    errors[0]!.reason.length > 0,
    `onError reason is descriptive: "${errors[0]!.reason.slice(0, 80)}..."`,
  );
}

section("Hook: handles pre-parsed object (non-string data)");

{
  const entries: WorldLogPayload[] = [];
  const { handleMessage } = useWorldLog({
    onEntry: (e) => entries.push(e),
  });

  // Simulate a runtime that auto-decodes JSON
  handleMessage({ data: VALID_EXPLORATION_PAYLOAD });
  assertEqual(entries.length, 1, "onEntry called for pre-parsed object");
}

/* ================================================================== */
/*  Summary                                                            */
/* ================================================================== */

console.log(`\n${"═".repeat(60)}`);
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log(`${"═".repeat(60)}\n`);

process.exit(failed > 0 ? 1 : 0);
