/**
 * game.ts — Unit tests for the XP distribution system.
 *
 * Run with:
 *   npx ts-node tests/game.ts
 *
 * Uses a minimal assertion helper so no external test framework is
 * required.
 */

import { Frog } from "../src/frog";
import { xpToNextLevel } from "../src/xpCurve";
import { distributeXp, XpResult } from "../src/xpDistributor";

/* ------------------------------------------------------------------ */
/*  Tiny assertion helpers                                             */
/* ------------------------------------------------------------------ */

let passed = 0;
let failed = 0;

function assert(condition: boolean, label: string): void {
  if (condition) {
    passed++;
    console.log(`  ✓  ${label}`);
  } else {
    failed++;
    console.error(`  ✗  ${label}`);
  }
}

function assertEqual<T>(actual: T, expected: T, label: string): void {
  assert(
    actual === expected,
    `${label} — expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`,
  );
}

function section(title: string): void {
  console.log(`\n── ${title} ${"─".repeat(56 - title.length)}`);
}

/* ------------------------------------------------------------------ */
/*  Helper: create a fresh Frog                                        */
/* ------------------------------------------------------------------ */

function makeFrog(
  overrides: Partial<Frog> = {},
): Frog {
  return {
    id: "frog-001",
    name: "Kermit",
    level: 1,
    xp: 0,
    ...overrides,
  };
}

/* ================================================================== */
/*  Tests                                                              */
/* ================================================================== */

// ----- xpToNextLevel sanity checks --------------------------------

section("xpToNextLevel curve");

assertEqual(xpToNextLevel(1), 100, "Level 1 → 2 costs 100 XP");
assertEqual(xpToNextLevel(2), 282, "Level 2 → 3 costs 282 XP");
assertEqual(xpToNextLevel(3), 519, "Level 3 → 4 costs 519 XP");
assertEqual(xpToNextLevel(4), 800, "Level 4 → 5 costs 800 XP");
assertEqual(xpToNextLevel(5), 1118, "Level 5 → 6 costs 1118 XP");

// ----- No level-up -------------------------------------------------

section("No level-up (XP below threshold)");

{
  const frog = makeFrog();
  const result = distributeXp(frog, 50);

  assertEqual(result.leveledUp, false, "leveledUp is false");
  assertEqual(result.newLevel, 1, "newLevel stays at 1");
  assertEqual(result.remainingXp, 50, "remainingXp is 50");
  assertEqual(frog.level, 1, "frog.level mutated to 1");
  assertEqual(frog.xp, 50, "frog.xp mutated to 50");
}

// ----- Exact single level-up ----------------------------------------

section("Exact single level-up (100 XP at Level 1)");

{
  const frog = makeFrog();
  const result = distributeXp(frog, 100);

  assertEqual(result.leveledUp, true, "leveledUp is true");
  assertEqual(result.newLevel, 2, "newLevel is 2");
  assertEqual(result.remainingXp, 0, "remainingXp is 0 (exact fit)");
  assertEqual(frog.level, 2, "frog.level mutated to 2");
  assertEqual(frog.xp, 0, "frog.xp mutated to 0");
}

// ----- Single level-up with remainder --------------------------------

section("Single level-up with remainder (150 XP at Level 1)");

{
  const frog = makeFrog();
  const result = distributeXp(frog, 150);

  assertEqual(result.leveledUp, true, "leveledUp is true");
  assertEqual(result.newLevel, 2, "newLevel is 2");
  assertEqual(result.remainingXp, 50, "remainingXp is 50");
  assertEqual(frog.xp, 50, "frog.xp carries over 50");
}

// ----- ★ KEY TEST: 5000 XP to a Level 1 Frog (multi-level skip) -----

section("★ 5000 XP to a Level 1 Frog (recursive multi-level-up)");

/*
 * Expected progression:
 *
 *   Level 1 → 2 :   100 XP   (remaining: 4900)
 *   Level 2 → 3 :   282 XP   (remaining: 4618)
 *   Level 3 → 4 :   519 XP   (remaining: 4099)
 *   Level 4 → 5 :   800 XP   (remaining: 3299)
 *   Level 5 → 6 :  1118 XP   (remaining: 2181)
 *   Level 6 → 7 :  1469 XP   (remaining:  712)
 *   Level 7 → 8 :  1852 XP   (remaining:  712 < 1852 → STOP)
 *
 *   Final level  = 7
 *   Remaining XP = 712
 */
{
  const frog = makeFrog(); // Level 1, 0 XP
  const result = distributeXp(frog, 5000);

  assertEqual(result.leveledUp, true, "leveledUp is true (gained 6 levels)");
  assertEqual(result.newLevel, 7, "newLevel is 7");
  assertEqual(result.remainingXp, 712, "remainingXp is 712");
  assertEqual(frog.level, 7, "frog.level mutated to 7");
  assertEqual(frog.xp, 712, "frog.xp mutated to 712 (DB value)");
}

// ----- Frog with pre-existing XP ------------------------------------

section("Pre-existing XP pushes over two thresholds");

{
  // Level 2 Frog with 250 XP already.  Needs 282 to reach Level 3.
  // Award 600 XP → total 850.
  //   850 >= 282 (L2→3) → level 3, remainder 568
  //   568 >= 519 (L3→4) → level 4, remainder  49
  //    49 <  800 (L4→5) → STOP
  const frog = makeFrog({ level: 2, xp: 250 });
  const result = distributeXp(frog, 600);

  assertEqual(result.leveledUp, true, "leveledUp is true");
  assertEqual(result.newLevel, 4, "newLevel is 4");
  assertEqual(result.remainingXp, 49, "remainingXp is 49");
}

// ----- Zero XP awarded -----------------------------------------------

section("Zero XP awarded");

{
  const frog = makeFrog({ level: 3, xp: 100 });
  const result = distributeXp(frog, 0);

  assertEqual(result.leveledUp, false, "leveledUp is false");
  assertEqual(result.newLevel, 3, "newLevel stays at 3");
  assertEqual(result.remainingXp, 100, "remainingXp unchanged at 100");
}

// ----- Negative XP throws --------------------------------------------

section("Negative XP throws RangeError");

{
  const frog = makeFrog();
  let threw = false;
  try {
    distributeXp(frog, -10);
  } catch (e) {
    threw = e instanceof RangeError;
  }
  assert(threw, "distributeXp(-10) throws RangeError");
}

/* ================================================================== */
/*  Summary                                                            */
/* ================================================================== */

console.log(`\n${"═".repeat(60)}`);
console.log(`  Results: ${passed} passed, ${failed} failed`);
console.log(`${"═".repeat(60)}\n`);

process.exit(failed > 0 ? 1 : 0);
