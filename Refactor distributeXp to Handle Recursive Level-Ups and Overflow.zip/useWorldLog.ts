/**
 * useWorldLog.ts
 *
 * Frontend hook (framework-agnostic) that receives World Log events
 * over a WebSocket and feeds them to a listener callback.
 *
 * Refactored to use a **type guard** (`isWorldLogPayload`) so that
 * malformed messages — including broken "God intervention" events —
 * are caught and logged instead of crashing the render tree with an
 * unhandled TypeError.
 *
 * The type guard delegates to `WorldLogPayloadSchema.safeParse` under
 * the hood, giving us both compile-time narrowing *and* runtime
 * structural validation in a single, idiomatic check.
 */

import {
  WorldLogPayload,
  WorldLogPayloadSchema,
} from "./game.schema";

/* ------------------------------------------------------------------ */
/*  Type guard                                                         */
/* ------------------------------------------------------------------ */

/**
 * Runtime type guard that returns `true` (and narrows `data` to
 * `WorldLogPayload`) only when the value satisfies every constraint
 * defined in `WorldLogPayloadSchema`.
 *
 * Usage:
 * ```ts
 * if (isWorldLogPayload(parsed)) {
 *   // `parsed` is now typed as WorldLogPayload
 *   renderLogEntry(parsed);
 * }
 * ```
 */
export function isWorldLogPayload(data: unknown): data is WorldLogPayload {
  return WorldLogPayloadSchema.safeParse(data).success;
}

/* ------------------------------------------------------------------ */
/*  Error callback                                                     */
/* ------------------------------------------------------------------ */

/**
 * Optional callback the consumer can supply to observe rejected
 * messages (telemetry, dev-tools logging, etc.).
 */
export type OnWorldLogError = (raw: unknown, reason: string) => void;

/* ------------------------------------------------------------------ */
/*  Hook                                                               */
/* ------------------------------------------------------------------ */

export interface UseWorldLogOptions {
  /** Called for every **valid** WorldLogPayload received. */
  onEntry: (entry: WorldLogPayload) => void;

  /**
   * Called when a message fails the type guard.
   * Defaults to `console.warn`.
   */
  onError?: OnWorldLogError;
}

/**
 * Simulated hook that processes incoming WebSocket messages.
 *
 * In a real React / Solid / Vue app this would manage a `useEffect`
 * lifecycle around the WebSocket connection.  Here we expose the
 * internal `handleMessage` so it can be unit-tested directly.
 */
export function useWorldLog(opts: UseWorldLogOptions) {
  const { onEntry, onError = defaultOnError } = opts;

  /**
   * Process a single raw WebSocket `MessageEvent`.
   *
   * 1. Attempt to JSON-parse the raw string.
   * 2. Run the parsed value through `isWorldLogPayload`.
   * 3. If valid → call `onEntry`.
   * 4. If invalid → call `onError` (never throw).
   */
  function handleMessage(raw: { data: unknown }): void {
    let parsed: unknown;

    // Step 1 — safe JSON parse
    if (typeof raw.data === "string") {
      try {
        parsed = JSON.parse(raw.data);
      } catch {
        onError(raw.data, "Failed to parse JSON from WebSocket message");
        return;
      }
    } else {
      // Already an object (e.g. binary → JSON auto-decoded by the runtime)
      parsed = raw.data;
    }

    // Step 2 + 3 — type-guard narrows `parsed` to WorldLogPayload
    if (isWorldLogPayload(parsed)) {
      onEntry(parsed);
      return;
    }

    // Step 4 — validation failed; surface the issue without crashing
    const result = WorldLogPayloadSchema.safeParse(parsed);
    const reason = result.success
      ? "Unknown validation failure"
      : result.error.issues
          .map((i) => `${i.path.join(".")}: ${i.message}`)
          .join("; ");

    onError(parsed, reason);
  }

  return { handleMessage };
}

/* ------------------------------------------------------------------ */
/*  Default error handler                                              */
/* ------------------------------------------------------------------ */

function defaultOnError(raw: unknown, reason: string): void {
  console.warn("[useWorldLog] Rejected malformed payload:", reason, raw);
}
